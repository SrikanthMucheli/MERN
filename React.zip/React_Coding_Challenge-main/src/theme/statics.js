const statics = {
   logo:'icon.png',
   field:'Field.png',

   logoW:30,
   logoH:30,

   fieldW:808,
   fieldH:541
}

export default statics;