const colors = {
        primary:'#FEA013',
        primaryDull:'#69563A',
        secondry:'#BA4A0C',
        primaryLight:'#D23131',

        neturalBlack:'#222222',
        neturalBlack2:'#2D2D2D',
        neturalBlack3:'#111111',

        textHeading:'#F8F8F8',
        textNormal:'#CBCBCB',
        textMuted:'#999999',
        textDisabled:'#707070',

        border:'#494949',
        red:'#D23131'
}

export default colors;