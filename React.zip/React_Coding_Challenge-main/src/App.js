import './App.css';
import Main from './router/main';
import colors from './theme/colors';

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
